# Risk Reversals (Short Put / Call)

**Risk reversals** are zero-cost or near-zero-cost directional option strategies where you simultaneously sell an out-of-the-money option in one direction and buy an out-of-the-money option in the opposite direction, creating a synthetic long or short stock position with defined risk on one side and unlimited potential on the other.





---

## The Core Insight

<p align="center">
<img src="https://github.com/SungchulLee/img/blob/main/risk_reversals_delta_comparison.png?raw=true" alt="long_call_vs_put" width="700">
</p>

**The fundamental idea:**

- You have strong directional conviction (bullish or bearish)
- Want exposure similar to owning/shorting stock
- But don't want to pay upfront premium
- Or don't want to tie up capital in stock purchase
- Risk reversal gives you stock-like exposure for zero cost
- You trade unlimited risk on one side for unlimited profit on the other
- Essentially creating synthetic stock position using options

**The key equation:**

$$
\text{Risk Reversal Cost} \approx \$0 \quad (\text{zero or minimal premium})
$$

$$
\text{Profit Potential} = \text{Unlimited (one direction)}
$$

$$
\text{Loss Potential} = \text{Unlimited (opposite direction)}
$$

**You're essentially betting: "Stock will move strongly in my direction, and I'm willing to accept unlimited risk on the opposite side to get stock-like exposure for free."**

---

## What Are Risk Reversals?

<p align="center">
<img src="https://github.com/SungchulLee/img/blob/main/risk_reversals_payoff.png?raw=true" alt="long_call_vs_put" width="700">
</p>

**Before trading risk reversals, understand the two main types:**

### 1. Bullish Risk Reversal (Synthetic Long Stock)

<p align="center">
<img src="https://github.com/SungchulLee/img/blob/main/risk_reversals_skew_trading.png?raw=true" alt="long_call_vs_put" width="700">
</p>

**Definition:** Sell OTM put, buy OTM call, typically for zero or small net cost/credit.

**Structure:**

- **Sell:** $95 put for $3.00 (take in premium)
- **Buy:** $105 call for $3.00 (pay premium)
- **Net Cost/Credit:** $0 (zero cost if balanced)

**The bet:** Stock will rally significantly above $105

**Risk/Reward:**

- Below $95: Unlimited downside (like owning stock)
- $95-$105: Flat range, no profit/loss (dead zone)
- Above $105: Unlimited upside (like owning stock)

**Economically equivalent to:**

- Owning 100 shares of stock
- But without paying for the stock upfront
- Accept downside risk in exchange for upside exposure

**Characteristics:**

- Bullish strategy (want big rally)
- Zero or minimal cost
- Unlimited upside potential
- Unlimited downside risk
- High delta exposure
- Exploits put-call skew

### 2. Bearish Risk Reversal (Synthetic Short Stock)

<p align="center">
<img src="https://github.com/SungchulLee/img/blob/main/risk_reversals_use_cases.png?raw=true" alt="long_call_vs_put" width="700">
</p>

**Definition:** Sell OTM call, buy OTM put, typically for zero or small net cost/credit.

**Structure:**

- **Sell:** $105 call for $3.00 (take in premium)
- **Buy:** $95 put for $3.00 (pay premium)
- **Net Cost/Credit:** $0 (zero cost if balanced)

**The bet:** Stock will decline significantly below $95

**Risk/Reward:**

- Above $105: Unlimited upside risk (like shorting stock)
- $95-$105: Flat range, no profit/loss (dead zone)
- Below $95: Large downside profit (like shorting stock)

**Economically equivalent to:**

- Shorting 100 shares of stock
- But without borrowing stock or margin
- Accept upside risk in exchange for downside profit

**Characteristics:**

- Bearish strategy (want big decline)
- Zero or minimal cost
- Large profit potential (stock to $0)
- Unlimited upside risk
- Negative delta exposure
- Exploits call-put skew

**Figure 1:** Profit/loss diagrams for bullish risk reversal (left) and bearish risk reversal (right), showing synthetic stock-like payoffs with unlimited risk on one side and unlimited/large profit on the other, typically entered for zero cost.

---

## Economic

<p align="center">
<img src="https://github.com/SungchulLee/img/blob/main/risk_reversals.png?raw=true" alt="risk_reversals" width="700">
</p>

**Beyond the basic definition, understanding what risk reversals REALLY are economically:**

### 1. Risk Reversals as Leveraged Stock Substitutes

<p align="center">
<img src="https://github.com/SungchulLee/img/blob/main/risk_reversal_delta.png?raw=true" alt="rr_delta" width="600">
</p>

**The deep insight:**

A risk reversal is economically equivalent to **owning or shorting stock without tying up capital, by accepting insurance obligations**. When you construct a risk reversal, you're essentially:

1. **Gaining stock-like exposure** (delta near ±1.00 when ITM)
2. **Selling insurance** to finance the position (short option premium)
3. **Buying lottery ticket** for directional move (long option)
4. **Accepting unlimited risk** on the side you don't expect

**Formal decomposition:**

$$
\underbrace{\text{Bullish Risk Reversal}}_{\text{Zero Cost}} \equiv \underbrace{\text{Long Stock}}_{\text{Delta +1.0}} - \underbrace{\text{Loan}}_{\text{Financed by put sale}}
$$

**Why this matters:**

**Traditional stock ownership:**

- Buy 100 shares at $100 = $10,000 capital
- Profit if stock rises
- Loss if stock falls
- **Need $10,000 upfront**

**Bullish risk reversal:**

- Sell $95 put, buy $105 call
- Net cost: $0
- Profit if stock > $105
- Loss if stock < $95
- **Need $0 upfront (aside from margin)**

**The put premium you collect finances the call premium you pay. This is "free leverage" - but you accept the downside risk as the cost.**

### 2. Example

**Setup:**

- AAPL at $180
- Bullish conviction (think it's going to $200+)

**Traditional approach:**

- Buy 100 shares at $180 = $18,000 capital
- Profit: $1 per $1 move above $180
- Loss: $1 per $1 move below $180

**Bullish Risk Reversal:**

- Sell $170 put for $4.50
- Buy $190 call for $4.50
- Net cost: $0

**What you're really doing:**

$$
\begin{align}
\text{Economic Position} &= \text{Long 100 shares (synthetically)} \\
&+ \text{Financed by selling downside insurance} \\
&+ \text{Profit only if rally above \$190} \\
&+ \text{Full downside risk below \$170}
\end{align}
$$

**Scenarios:**

| AAPL at Expiry | Own Stock | Risk Reversal |
|---------------|-----------|---------------|
| $200 | Gain: $2,000 | Gain: $1,000 ($10 above $190 call) |
| $190 | Gain: $1,000 | Breakeven |
| $180 | Breakeven | Breakeven |
| $170 | Loss: -$1,000 | Breakeven |
| $160 | Loss: -$2,000 | Loss: -$1,000 (assigned put at $170) |
| $150 | Loss: -$3,000 | Loss: -$2,000 (same as stock below $170) |

**The "dead zone":** Between $170-$190, risk reversal does nothing while stock makes money

**This "zero cost leverage" comes at the price of:**

1. Dead zone where you don't participate ($170-$190)
2. Same downside risk as stock below put strike
3. No dividends
4. Assignment risk

### 3. The Volatility Skew Arbitrage

**Risk reversals exploit an inefficiency in options markets:**

**The skew:**

- OTM puts typically more expensive than OTM calls (put skew)
- Market pays premium for downside protection
- Calls are "cheap" relative to puts
- This creates opportunity!

**Bullish Risk Reversal exploits this:**

$$
\text{Sell Expensive Put} + \text{Buy Cheap Call} = \text{Free or Credit Position}
$$

**Example:**

- Stock at $100
- $95 put (5% OTM): IV = 35%, costs $4.50
- $105 call (5% OTM): IV = 28%, costs $3.00
- **Net credit: $1.50!**

You actually GET PAID to take on synthetic long stock exposure!

**Why the skew exists:**

1. **Fear premium:** Investors overpay for put protection
2. **Institutional hedging:** Funds constantly buying puts
3. **Covered call selling:** Funds constantly selling calls
4. **Result:** Puts expensive, calls cheap

**Professional traders exploit this:**

- Sell rich puts (collect fat premium)
- Buy cheap calls (pay less)
- Net credit or zero cost
- Gain stock-like exposure
- **Get paid to take on bullish position!**

### 4. Put-Call Parity and Synthetic Positions

**The fundamental options equation:**

$$
C - P = S - K e^{-rT}
$$

**Rearranging:**

$$
S = C - P + K e^{-rT}
$$

**Translation:**

$$
\text{Long Stock} \equiv \text{Long Call} - \text{Short Put} + \text{Cash}
$$

**Risk reversal is this relationship without the cash:**

$$
\text{Risk Reversal} = \text{Long Call} - \text{Short Put}
$$

**This is synthetic stock without paying for the stock upfront!**

**The arbitrage relationship:**

If risk reversal costs significantly more/less than theoretical:
- Arbitrageurs step in
- Buy cheap side, sell expensive side
- Lock in riskless profit
- Market efficiency restored

**But small deviations persist due to:**

- Volatility skew
- Supply/demand imbalances  
- Financing costs
- Dividend expectations
- **These deviations create opportunity for risk reversals**

### 5. Why This Perspective Matters

**Understanding risk reversals as synthetic stock helps you:**

1. **Compare to direct stock ownership:**

   - Stock: Pay $10,000, full exposure immediately
   - Risk reversal: Pay $0, exposure only outside strikes
   - **Which is better depends on conviction and timeframe**

2. **Understand the "free lunch" trap:**

   - Zero cost seems free
   - But you're taking on insurance obligations
   - Margin required for short put
   - Assignment risk
   - **Not actually free - just deferred payment**

3. **Recognize skew opportunities:**

   - When put-call skew is wide (puts expensive)
   - Bullish RR can collect net credit
   - You're paid to take bullish position
   - **Skew is your edge**

4. **Portfolio applications:**

   - Instead of buying stock, use RR
   - Free up capital for other trades
   - Leverage buying power
   - Collar = RR + actual stock ownership

### 6. The Strategic Advantage of Zero-Cost Directional Exposure

**Why traders prefer risk reversals over stock:**

**Scenario: Very bullish on TSLA at $220**

**Option A: Buy 100 Shares**
- Cost: $22,000
- Profit: $1 per $1 move up
- Loss: $1 per $1 move down
- Capital tied up: $22,000

**Option B: Bullish Risk Reversal**
- Sell $210 put for $8
- Buy $235 call for $8  
- Cost: $0
- Profit: $1 per $1 above $235
- Loss: Full downside below $210
- Capital tied up: ~$2,000 margin (put side)

**The risk reversal gives you:**

- 90% less capital required
- Same unlimited upside (above $235)
- Same downside risk (below $210)
- Dead zone $210-$235 (opportunity cost)
- **Leverage buying power 10x**

**When to choose each:**

**Buy stock when:**

- Want immediate participation in all moves
- Dividend income important
- Long-term hold (years)
- Less conviction about explosive move

**Risk reversal when:**

- Very strong directional conviction
- Expect big move in near term
- Want to preserve capital
- Exploit volatility skew
- **High conviction + limited capital**

**This is why institutional traders use risk reversals for tactical directional bets while preserving capital for other opportunities.**

---

## Key Terminology

**Risk Reversal (RR):**

- Also called "collar without stock" or "synthetic long/short"
- Sell option one direction, buy option other direction
- Typically zero or near-zero cost
- Creates stock-like exposure

**Skew:**

- Difference in implied volatility across strikes
- OTM puts usually higher IV than OTM calls
- Creates opportunity for risk reversals
- "Put skew" = puts expensive relative to calls

**Dead Zone:**

- Price range between strikes where position flat
- No profit, no loss in this range
- Opportunity cost if stock stays here
- Wider dead zone = less sensitive to price

**Strike Symmetry:**

- How far strikes are from current price
- Symmetric: Equal distance (e.g., ±5%)
- Asymmetric: Different distances (e.g., -3%, +8%)
- Affects cost and risk profile

**Delta Profile:**

- How delta changes across prices
- Below put strike: Delta ≈ -1.0 (like short stock)
- In dead zone: Delta ≈ 0
- Above call strike: Delta ≈ +1.0 (like long stock)
- S-shaped curve

**Cost Basis:**

- Net debit or credit from entering position
- Zero-cost: Premiums balance
- Credit: Collect net premium (ideal)
- Debit: Pay net premium (less attractive)

**Assignment Risk:**

- Short put can be assigned if ITM
- Forced to buy 100 shares at strike
- Ties up capital unexpectedly
- Need sufficient buying power

---

## Why Use Risk Reversals?

**Use cases for different variations:**

### 1. Bullish Risk Reversal (Sell Put / Buy Call)

**When to use:**

1. **Very strong bullish conviction:**

   - Believe stock will rally significantly
   - Don't just want "some upside"
   - Want unlimited upside participation
   - Willing to accept downside risk

2. **Capital efficiency:**

   - Want stock exposure but limited capital
   - Preserve cash for other opportunities
   - Leverage buying power
   - Can't afford to buy 100 shares

3. **Skew exploitation:**

   - Puts expensive (high put skew)
   - Collecting fat put premium
   - Calls cheap relative to puts
   - Net credit or zero cost achievable

4. **Avoiding early capital outlay:**

   - Don't want to tie up $10,000+ in stock
   - But want to participate in rally
   - Defer capital commitment until assignment
   - Speculative play with limited upfront cost

5. **Pre-event positioning:**

   - Catalyst coming (FDA, earnings, product launch)
   - Expect explosive move up
   - Don't want to pay high premium for straight call
   - Finance call purchase by selling put

**Example scenario:**

- NVDA at $500 (AI boom continuing)
- Very bullish, think it's going to $600+
- Can't afford $50,000 for 100 shares
- Puts expensive (IV = 40%), calls cheaper (IV = 32%)
- **Action:** Bullish risk reversal
  - Sell $475 put for $18
  - Buy $525 call for $15
  - **Net credit: $3 ($300 total)**
- Profit if NVDA rallies above $522 (call strike - credit)
- Risk if NVDA drops below $478 (put strike + credit)

### 2. Bearish Risk Reversal (Sell Call / Buy Put)

**When to use:**

1. **Very strong bearish conviction:**

   - Believe stock will decline significantly
   - Want to profit from major drop
   - Willing to accept upside risk
   - Can't or won't short stock

2. **Alternative to shorting stock:**

   - No stock borrow available
   - Avoid short sale constraints
   - Don't want to pay borrow fees
   - Want defined upside risk (vs. short stock)

3. **Overvaluation plays:**

   - Stock fundamentally expensive
   - Expecting major correction
   - Want big profit if crash happens
   - Accept risk if rally continues

4. **Event-driven downside:**

   - Expecting bad news (earnings miss, scandal, etc.)
   - Want convexity on downside
   - Cheaper than buying puts outright
   - Finance put purchase by selling call

5. **Hedging without cost:**

   - Have other positions to protect
   - Want downside protection
   - Don't want to pay for puts
   - Sell calls to finance puts (if bearish overall)

**Example scenario:**

- Bubble stock at $200 (way overvalued)
- Very bearish, think it crashes to $150 or lower
- Can't short (no borrow or too expensive)
- Calls expensive (call skew), puts cheaper
- **Action:** Bearish risk reversal
  - Sell $215 call for $12
  - Buy $185 put for $11
  - **Net credit: $1 ($100 total)**
- Profit if stock declines below $184 (put strike - credit)
- Risk if stock rallies above $216 (call strike + credit)

---

## The Greeks

**How Greeks create stock-like behavior:**

### 1. Delta (Directional Exposure)

**Bullish Risk Reversal Delta Evolution:**

$$
\Delta_{\text{bullish RR}} = \Delta_{\text{long call}} - \Delta_{\text{short put}}
$$

**Delta across prices:**

| Stock Price | Call Delta | Put Delta (short) | Total Delta | Behavior |
|------------|-----------|------------------|-------------|----------|
| $90 (below put) | +0.05 | -(-0.95) = +0.95 | **+1.00** | Like long stock |
| $95 (at put) | +0.10 | -(-0.50) = +0.50 | +0.60 | Building up |
| $100 (middle) | +0.30 | -(-0.20) = +0.20 | +0.50 | Moderate |
| $105 (at call) | +0.50 | -(-0.05) = +0.05 | +0.55 | Building up |
| $110 (above call) | +0.95 | -(0.00) = 0.00 | **+0.95** | Like long stock |

**The S-curve pattern:**


**Key insights:**

- Outside strikes: Delta ≈ ±1.0 (stock-like)
- Inside strikes (dead zone): Delta ≈ 0.3-0.6 (muted)
- At strikes: Delta changes rapidly
- **This creates non-linear P&L**

**Bearish Risk Reversal:**

Similar pattern but inverted:
- Below put strike: Delta ≈ -1.0 (like short stock)
- Dead zone: Delta ≈ -0.3 to -0.6
- Above call strike: Delta ≈ -1.0 (like short stock)

### 2. Gamma (Delta Acceleration)

**Risk reversals have complex gamma:**

$$
\Gamma_{\text{RR}} = \Gamma_{\text{long option}} - \Gamma_{\text{short option}}
$$

**Gamma across prices:**

| Stock Position | Long Call Gamma | Short Put Gamma | Net Gamma | Effect |
|---------------|----------------|----------------|-----------|---------|
| Far below strikes | Low | Medium | **Negative** | Delta decays toward +1.0 |
| At put strike | Low | **High** | **Negative** | Delta whipsaw |
| Dead zone | Low | Low | ~Zero | Stable delta |
| At call strike | **High** | Low | **Positive** | Delta accelerates |
| Far above strikes | Medium | Low | Positive | Delta approaches +1.0 |

**The gamma pattern:**

- **Negative gamma at short option strike** (dangerous!)
- Positive gamma at long option strike (helpful)
- Net effect: Complex risk profile
- Near expiration: Gamma explodes at strikes

**What this means:**

**If stock at short put strike:**

- Negative gamma is high
- Delta whipsaws -0.50 to -1.0 quickly
- **Danger zone - high assignment risk**

**If stock at long call strike:**

- Positive gamma is high
- Delta accelerates 0.50 to 1.0
- **Sweet spot - profit accelerates**

### 3. Theta (Time Decay) - Double-Edged Sword

**Risk reversals have offsetting theta:**

$$
\Theta_{\text{RR}} = \Theta_{\text{long call}} + \Theta_{\text{short put}}
$$

**Theta composition:**

- Long call: Theta < 0 (decay hurts you)
- Short put: Theta > 0 (decay helps you)
- **Net theta ≈ 0 if strikes equidistant**

**But theta distribution matters:**

**In the dead zone (between strikes):**

- Both options losing time value
- Net theta approximately zero
- **Time passing doesn't help or hurt much**

**Below put strike (ITM put):**

- Put mostly intrinsic value
- Call decaying to zero
- **Net theta slightly negative**

**Above call strike (ITM call):**

- Call mostly intrinsic value
- Put decaying to zero
- **Net theta slightly negative**

**The theta trap:**

Unlike credit spreads where theta helps consistently, risk reversals are theta-neutral in dead zone but theta-negative outside strikes. This means:
- Time passage doesn't help in range (opportunity cost)
- Time passage hurts once you're winning (option decay)
- **Need move to happen before expiration**

**Time decay by DTE:**

| DTE | Dead Zone Theta | ITM Theta | Strategy |
|-----|----------------|-----------|----------|
| 90+ | ~$0 | -$5/day | Can wait for move |
| 60 | ~$0 | -$8/day | Moderate urgency |
| 30 | ~$0 | -$15/day | Need move soon |
| 7 | ~$0 | -$40/day | Desperate - close or roll |

### 4. Vega (Volatility Risk) - Also Offsetting

**Risk reversals have near-zero net vega:**

$$
\text{Vega}_{\text{RR}} = \text{Vega}_{\text{long call}} - \text{Vega}_{\text{short put}}
$$

**Vega composition:**

- Long call: Vega > 0 (IV increase helps)
- Short put: Vega > 0, but you're short (IV increase hurts)
- **Net vega ≈ 0 if strikes similar**

**But vega skew matters:**

**If put skew exists (puts more expensive):**

- Short put has higher vega
- Long call has lower vega
- **Net vega slightly negative**
- IV increase hurts slightly

**Example:**

- Short $95 put: Vega = +0.30, IV = 35%
- Long $105 call: Vega = +0.25, IV = 28%
- Net vega = +0.25 - 0.30 = -0.05
- **IV spike of 10% → lose $50**

**The vega benefit:**

Risk reversals are relatively **vega-neutral**:
- Not hurt badly by IV crush (unlike long options)
- Not helped much by IV expansion (unlike short options)
- **Focus on directional move, not IV changes**

**Exception: Skew trades:**

Some traders specifically use RRs to trade the skew:
- If put skew very high → sell puts, buy calls
- Collect net credit from skew
- Profit if skew normalizes (even if stock flat)
- **Advanced strategy**

### 5. Rho (Interest Rate Risk) - Matters for Long-Term

**Risk reversals have offsetting rho:**

$$
\text{Rho}_{\text{bullish RR}} = \text{Rho}_{\text{call}} - \text{Rho}_{\text{put}} > 0
$$

**For short-term RRs (<90 days):**

- Rho effect negligible
- Can ignore

**For long-term RRs (6+ months, LEAPS):**

- Rho becomes meaningful
- Higher rates favor bullish RR (calls worth more)
- Lower rates favor bearish RR (puts worth more)
- **Consider rate environment for LEAPS RRs**

---

## Strike Selection Strategy

**Where you place strikes determines everything:**

### 1. The Symmetry Decision

**Symmetric Strikes (Equal Distance):**

**Structure:**

- Current price: $100
- Sell $95 put (5% OTM)
- Buy $105 call (5% OTM)
- Equal distance from spot

**Pros:**

- Balanced risk/reward
- Intuitive to understand
- Usually near-zero cost
- Standard approach

**Cons:**

- Dead zone may be too wide
- Less customization
- May not optimize skew

**Use when:**

- Standard directional bet
- No strong skew to exploit
- Want simplicity

**Asymmetric Strikes (Different Distances):**

**Structure (bullish example):**

- Current price: $100
- Sell $97 put (3% OTM) - closer
- Buy $110 call (10% OTM) - farther
- Asymmetric placement

**Pros:**

- Can collect net credit (if skew favorable)
- Optimize risk/reward for conviction
- Exploit volatility skew
- Flexible

**Cons:**

- More complex
- May cost more or less
- Requires skew analysis

**Use when:**

- Strong skew exists
- Want to optimize credit
- Have specific risk tolerance

### 2. The Delta-Based Approach (Professional Standard)

**Choose strikes by delta, not absolute distance:**

**Conservative (Wide Dead Zone):**

- Sell 15-20 delta option
- Buy 15-20 delta option
- Wide dead zone (15-20% range)
- Low probability of breaching strikes
- Near-zero cost typically

**Example:**

- Stock at $100
- Sell $90 put (18-delta)
- Buy $112 call (18-delta)
- Dead zone: $90-$112 (22% range)

**Balanced (Medium Dead Zone):**

- Sell 25-30 delta option
- Buy 25-30 delta option
- Medium dead zone (10-15% range)
- Moderate probability
- May collect small credit

**Example:**

- Stock at $100
- Sell $95 put (28-delta)
- Buy $107 call (28-delta)
- Dead zone: $95-$107 (12% range)

**Aggressive (Narrow Dead Zone):**

- Sell 35-40 delta option
- Buy 35-40 delta option
- Narrow dead zone (6-10% range)
- High probability of breaching
- Usually net debit

**Example:**

- Stock at $100
- Sell $98 put (38-delta)
- Buy $103 call (38-delta)
- Dead zone: $98-$103 (5% range)

### 3. The Credit Collection Strategy

**Optimize for net credit by exploiting skew:**

**Bullish RR Credit Optimization:**

Goal: Collect maximum credit while maintaining bullish bias

**Steps:**

1. Find put with highest IV (usually lower strikes)
2. Sell that put for fat premium
3. Find call with lower IV (usually higher strikes)
4. Buy call for less premium
5. Net credit = directional bet you get PAID for

**Example:**

- Stock at $100
- $92 put: IV = 38%, premium = $5.50
- $108 call: IV = 30%, premium = $4.00
- **Net credit: $1.50 ($150 per RR)**

You're paid $150 to take bullish position!

**Bearish RR Credit Optimization:**

Goal: Collect credit on bearish position

**Reality: Harder to achieve**
- Call skew usually lower than put skew
- Selling calls collects less than buying puts costs
- Typically pay small debit for bearish RR
- **But sometimes achievable in meme stocks with high call IV**

**Example (unusual scenario):**

- Meme stock at $50 (retail call buying frenzy)
- $55 call: IV = 90%, premium = $8.00 (retail buying)
- $45 put: IV = 70%, premium = $6.50
- **Net credit: $1.50**

Rare, but exploitable when it happens.

### 4. The Probability-Weighted Approach

**Optimize based on expected move:**

**Calculate expected move:**

$$
\text{Expected Move} = \text{Stock Price} \times \text{IV} \times \sqrt{\frac{\text{DTE}}{365}}
$$

**Example:**

- Stock at $100
- IV = 40%
- DTE = 60 days

$$
\text{Expected Move} = 100 \times 0.40 \times \sqrt{\frac{60}{365}} = 100 \times 0.40 \times 0.406 = \$16.24
$$

**Strike placement:**

**For bullish RR:**

- Sell put at: Price - (Expected Move × 0.8) = $100 - $13 = $87
- Buy call at: Price + (Expected Move × 1.2) = $100 + $19.50 = $119.50
- **Asymmetric: Put closer (expect upside, not downside)**

**For bearish RR:**

- Sell call at: Price + (Expected Move × 0.8) = $113
- Buy put at: Price - (Expected Move × 1.2) = $80.50
- **Asymmetric: Call closer (expect downside, not upside)**

### 5. The Capital Efficiency Optimization

**Balance between:**

**Wider strikes (more capital efficient):**

- Lower assignment probability
- Larger dead zone
- More time for directional move
- Less capital at risk
- **Better for long-term convictions**

**Tighter strikes (more responsive):**

- Higher assignment probability
- Smaller dead zone
- Quicker participation
- More capital at risk
- **Better for short-term convictions**

**Example comparison:**

**Wide strikes (conservative):**

- Stock at $100
- Sell $85 put / Buy $115 call
- Assignment prob: 10%
- Capital at risk if assigned: $8,500
- Dead zone: 30%

**Tight strikes (aggressive):**

- Stock at $100
- Sell $95 put / Buy $105 call
- Assignment prob: 30%
- Capital at risk if assigned: $9,500
- Dead zone: 10%

**Choose based on:**

- Conviction level (high = tight, medium = wide)
- Capital availability (limited = wide, ample = tight)
- Time horizon (short = tight, long = wide)

---

## Time Selection

### 1. Entry Timing

**Different from other strategies:**

**Enter risk reversals 60-90 days to expiration:**

**Why longer timeframes?**

1. **Directional move needs time:**

   - Stock rarely moves huge in 30 days
   - Need 2-3 months for thesis to play out
   - More time = more probability of breach

2. **Theta relatively neutral:**

   - Not like credit spreads (theta helps)
   - Theta ≈ 0 in dead zone
   - So longer time doesn't hurt much

3. **Avoid gamma explosion:**

   - <30 DTE, gamma explodes at strikes
   - Assignment risk increases dramatically
   - Need time buffer

4. **Skew more pronounced:**

   - Longer-dated options show more skew
   - Better opportunity for credit collection
   - Skew flattens near expiration

**Comparison:**

| DTE | Theta Impact | Gamma Risk | Skew | Time for Move | Verdict |
|-----|-------------|------------|------|---------------|---------|
| 90+ | Minimal | Very Low | **Best** | Plenty | **Good** |
| 60-90 | Low | Low | Good | Adequate | **✓ Best** |
| 30-60 | Medium | Medium | Moderate | Rushed | Acceptable |
| <30 | High | **High** | Low | Insufficient | **Avoid** |

### 2. Exit Timing

**Risk reversals need different exit logic:**

### 3. Rule 1

**If stock breaches long option strike:**

**Close when gain = 50-100% of dead zone width**

**Example - Bullish RR:**

- Dead zone: $95 (put) to $105 (call) = $10 wide
- Stock rallies to $110 (breached call strike)
- Current value: +$5 per share = $500
- **Target: 50% of dead zone = $5 achieved!**
- **Action: Close and take profit**

**Why close at this point?**
- Theta accelerating against you
- Assignment risk on short put increasing
- Already achieved significant gain
- Further upside has diminishing returns

**Don't get greedy:**

- Stock at $120? Awesome, but close it
- You're up $15, target was $5-$10
- Additional exposure not worth the risks
- Take win, move on

### 4. Rule 2

**If stuck in dead zone for >50% of timeframe:**

**Close and redeploy capital elsewhere**

**Example:**

- Entered 90-DTE RR
- 45 days passed (50% of time)
- Stock still in dead zone
- No progress toward profitable zone
- **Action: Close for small loss/gain, exit**

**Why exit?**
- Opportunity cost too high
- Capital tied up in margin
- Better opportunities likely exist
- Unlikely to breach with <45 days left

### 5. Rule 3

**If stock approaches short option strike (within 2%):**

**Close immediately if:**

- Less than 21 DTE remaining
- Assignment would be problematic
- Negative gamma accelerating

**Example - Bullish RR:**

- Sold $95 put
- Stock drops to $97 (within 2%)
- 18 DTE remaining
- **Action: Close entire RR immediately**

**Why close?**
- Assignment risk very high
- Gamma explosion imminent
- Could be forced to buy 100 shares at $95
- Better to exit clean than risk assignment

### 6. Rule 4

**If fundamental thesis invalidated:**

**Close immediately regardless of P/L**

**Example:**

- Bullish RR on growth stock
- Fed turns hawkish (bearish for growth)
- Original thesis broken
- Position slightly profitable but wrong direction
- **Action: Close now, don't wait**

**Thesis trumps technicals:**

- If reason for trade invalid, exit
- Don't let stubbornness cost you
- Accept small loss to avoid big loss
- **Flexibility > being right**

### 7. Rolling Strategies

**When and how to roll risk reversals:**

### 8. Scenario 1

**Situation:**

- Stock moved in your favor (breached long strike)
- Profitable but approaching expiration
- Want to maintain exposure

**Action: Roll up and out (bullish) or down and out (bearish)**

**Example - Bullish RR:**

- Currently: Short $95 put, Long $105 call
- Stock at $110, call ITM
- 30 DTE left
- **Roll:**

  - Close current RR for profit
  - Open new RR: Short $105 put, Long $115 call
  - 60 DTE
  - Locks in some profit, maintains upside exposure

### 9. Scenario 2

**Situation:**

- Stock stuck between strikes
- Time passing (opportunity cost)
- Still have conviction

**Action: Roll to tighter strikes or different expiration**

**Example:**

- Currently: Short $95 put, Long $105 call
- Stock at $100 for 60 days
- 30 DTE left, going nowhere
- **Options:**

  1. Roll out: Same strikes, 60 more days (more time)
  2. Tighten: Short $98 put, Long $103 call (narrow dead zone)
  3. Exit: Close for small loss, move on (usually best)

### 10. Scenario 3

**Situation:**

- Stock approaching short strike
- Assignment risk high
- Don't want to be assigned

**Action: Roll short strike farther out**

**Example - Bullish RR threatened:**

- Stock dropping toward $95 put strike
- Don't want to be assigned 100 shares
- **Roll:**

  - Buy back $95 put
  - Sell $90 put (farther OTM)
  - Collect or pay small difference
  - Reduces assignment probability

**When NOT to roll:**

- Already rolled once (don't chase)
- Thesis completely broken
- Better to take assignment than keep rolling
- **Accept outcome, don't fight it**

---

## Maximum Profit and Loss Analysis

### 1. Mathematical Formulas

**Bullish Risk Reversal:**

$$
\text{Max Loss} = (\text{Put Strike} - 0) - \text{Net Credit} \quad (\text{if put exercised at } \$0)
$$

$$
\text{Max Profit} = \text{Unlimited} \quad (\text{call can go to infinity})
$$

$$
\text{Breakeven (downside)} = \text{Put Strike} - \text{Net Credit}
$$

$$
\text{Breakeven (upside)} = \text{Call Strike} + \text{Net Debit}
$$

**Example (zero cost):**

- Sell $95 put for $4.00
- Buy $105 call for $4.00
- Net cost: $0

**Calculations:**

- Max loss: $95 - $0 = $9,500 (if stock to $0)
- Max profit: Unlimited (if stock to infinity)
- Downside breakeven: $95 - $0 = $95
- Upside breakeven: $105 + $0 = $105
- Dead zone: $95-$105

**Profit/loss table:**

| Stock Price | Put P/L | Call P/L | Total P/L |
|------------|---------|----------|----------|
| $0 | -$9,500 | $0 | **-$9,500** (max loss) |
| $85 | -$1,000 | $0 | -$1,000 |
| $95 | $0 | $0 | $0 (breakeven) |
| $100 | $0 | $0 | $0 (dead zone) |
| $105 | $0 | $0 | $0 (breakeven) |
| $115 | $0 | +$1,000 | +$1,000 |
| $125 | $0 | +$2,000 | +$2,000 |
| $150+ | $0 | +$4,500+ | **+$4,500+** (unlimited) |

**Bearish Risk Reversal:**

$$
\text{Max Loss} = \text{Unlimited} \quad (\text{short call, stock can go to infinity})
$$

$$
\text{Max Profit} = \text{Put Strike} - \text{Net Debit} \quad (\text{stock to } \$0)
$$

$$
\text{Breakeven (upside)} = \text{Call Strike} + \text{Net Credit}
$$

$$
\text{Breakeven (downside)} = \text{Put Strike} - \text{Net Debit}
$$

**Example (small debit):**

- Sell $105 call for $3.50
- Buy $95 put for $4.00
- Net debit: $0.50

**Calculations:**

- Max loss: Unlimited (if stock to infinity)
- Max profit: $95 - $0.50 = $9,450 (if stock to $0)
- Upside breakeven: $105 + $0 = $105 (collected $3.50 call - paid $4.00 put)
- Downside breakeven: $95 - $0.50 = $94.50
- Dead zone: $94.50-$105

### 2. The Dead Zone Cost Analysis

**Critical concept: Opportunity cost of dead zone**

**Example:**

- Bullish RR: $95 put / $105 call
- Stock stays at $100 for 60 days
- Net result: $0 gain

**Comparison to stock ownership:**

**Own stock at $100:**

- Stock at $100 after 60 days
- Result: $0 gain (same)
- Plus: Received dividends (if any)
- **No worse than RR in dead zone**

**But what if stock at $103?**

**Own stock:**

- Gain: $300 (3% move)

**Risk Reversal:**

- Gain: $0 (still in dead zone)
- **Opportunity cost: $300**

**The dead zone penalty:**

$$
\text{Opportunity Cost} = (\text{Stock Move}) \times 100 \quad \text{if move within dead zone}
$$

**Example:**

- Stock moves from $100 → $103 (+3%)
- Stock owner gains: $300
- RR holder gains: $0
- **Opportunity cost: $300**

**This is the price you pay for zero-cost leverage!**

### 3. Return on Risk Analysis (Compared to Stock)

**The leverage comparison:**

**Scenario: Very bullish on AAPL at $180**

**Option A: Buy 100 Shares**
- Capital: $18,000
- Profit if $200: $2,000
- ROI: 11.1%
- Risk: $18,000 if stock to $0

**Option B: Bullish RR ($170 put / $190 call, zero cost)**
- Capital: $0 upfront (margin for put: ~$1,700)
- Profit if $200: $1,000
- ROI: Infinite (on zero cost) or 59% (on margin)
- Risk: $17,000 if stock to $0

**Risk-adjusted comparison:**

| Metric | Buy Stock | Risk Reversal |
|--------|-----------|---------------|
| Upfront capital | $18,000 | $0 |
| Margin required | $0 | $1,700 |
| Profit at $200 | $2,000 | $1,000 |
| ROI (on capital) | 11.1% | Infinite |
| Max loss | $18,000 | $17,000 |
| Breakeven | $180 | $190 |
| Dead zone cost | $0 | $180-$190 range |

**When RR is better:**

- Limited capital available
- Very strong conviction (think $200+)
- Short-term speculation
- Want leverage

**When stock is better:**

- Moderate conviction
- Long-term hold
- Want dividends
- Don't want dead zone risk

### 4. Skew Value Analysis

**The "free money" from skew:**

**Example with put skew:**

- Stock at $100
- $95 put: IV = 36%, costs $4.50
- $105 call: IV = 29%, costs $3.00
- **Net credit: $1.50**

**Skew value calculation:**

If options were priced at same IV (32% average):
- $95 put would cost: $3.75
- $105 call would cost: $3.75
- Net cost: $0

**But actual pricing:**

- Net credit: $1.50

**Skew value: $1.50**

**This $1.50 is the "edge" from volatility skew!**

**Interpretation:**

- You're getting paid $150 to take bullish position
- This is the market's "fear premium"
- Institutional hedgers overpaying for puts
- You collect this overpayment
- **Pure arbitrage value from skew**

---

## When to Enter Risk Reversals

### 1. Market Conditions

**Best environments:**

### 2. Strong Trending Markets

**The ideal setup:**

- Clear trend established (up or down)
- Momentum accelerating
- Expect continuation
- Want leveraged exposure

**Bullish example:**

- SPY in uptrend from $500 → $550
- Breaks resistance at $550
- Economic data supporting rally
- **Enter bullish RR:** Sell $540 put, Buy $565 call
- Capture continued upside with zero cost

**Bearish example:**

- Stock in downtrend from $80 → $60
- Breaks support at $60
- Fundamentals deteriorating
- **Enter bearish RR:** Sell $65 call, Buy $55 put
- Capture continued decline

### 3. High Conviction Pre-Event

**Before major catalyst:**

- FDA decision, product launch, earnings, etc.
- High conviction on direction
- Don't want to pay high premium
- Use RR instead of straight call/put

**Example:**

- Biotech pending FDA approval
- Very bullish on approval
- Calls expensive (IV = 80%)
- **Enter bullish RR:**

  - Sell $45 put (IV = 70%) for $9
  - Buy $65 call (IV = 80%) for $8
  - Net credit: $1
- Profit hugely if approval
- Risk if rejection (but would lose anyway)

### 4. Volatility Skew Extremes

**When skew is exceptionally wide:**

- Put IV >> Call IV (typical)
- Put skew at extremes (fear peak)
- Can collect significant credit
- **Arbitrage opportunity**

**How to identify:**

Check IV percentile by strike:
- If $95 put IV at 90th percentile
- But $105 call IV at 40th percentile
- **Extreme skew = opportunity**

**Example:**

- Market panic, VIX spiked
- Stock at $100
- $90 put: IV = 55% (fear premium)
- $110 call: IV = 35% (call sellers)
- Sell put for $7.50, buy call for $4.00
- **Net credit: $3.50**

This is insurance companies overpaying for protection!

### 5. Post-Correction Entry

**After market sells off:**

- Stock corrected 10-20%
- Finding support
- Bullish on recovery
- Want leveraged exposure

**Example:**

- Tech stock dropped from $200 → $160 (-20%)
- Support at $155 holding
- Sector rotation positive
- **Enter bullish RR:** Sell $150 put, Buy $175 call
- Zero cost exposure to recovery
- Max risk if further collapse (don't expect)

### 6. Technical Setups

### 7. Bullish RR - Technical Signals

**1. Breakout confirmations:**

- Stock breaks major resistance
- Volume confirming
- Want continued rally exposure
- **Sell puts below breakout, buy calls above**

**2. Trend resumptions:**

- Uptrend intact
- Healthy pullback to support
- Expect resumption
- **RR captures upside without capital**

**3. Reversal patterns:**

- Double bottom, inverse H&S
- Bullish reversal confirmed
- Want to ride new uptrend
- **RR better than buying stock (leverage)**

### 8. Bearish RR - Technical Signals

**1. Breakdown confirmations:**

- Stock breaks major support
- Volume confirming
- Want to profit from decline
- **Sell calls above breakdown, buy puts below**

**2. Downtrend continuations:**

- Downtrend intact
- Dead cat bounce to resistance
- Expect continuation down
- **RR captures downside**

**3. Reversal patterns:**

- Double top, H&S
- Bearish reversal confirmed
- Want to profit from decline
- **RR better than shorting (no borrow)**

### 9. Volatility-Based Entry

**Using IV rank for timing:**

### 10. Bullish RR Entry Conditions

**Best when:**

**Put IV Rank > 60% (puts expensive):**

- Collect fat premium from put sale
- Fear premium at peak
- Calls relatively cheap
- **Maximum skew arbitrage**

**Example:**

- Stock IV rank: 65%
- Put skew extreme
- Sell puts, buy calls
- Collect credit + directional exposure

### 11. Bearish RR Entry Conditions

**Best when:**

**Call IV Rank > 60% (calls expensive - rare):**

- Meme stocks, retail call buying
- Collect premium from call sale
- Puts relatively cheaper
- **Reverse skew arbitrage**

**Example (GME-style):**

- Meme stock with retail frenzy
- Calls bid up to extreme IV
- **Sell calls, buy puts**
- Collect credit + bearish exposure

---

## When to Avoid Risk Reversals

### 1. Neutral/Range-Bound Expectations

**The worst scenario for RR:**

- Stock trading in tight range
- No directional conviction
- Expect continued consolidation
- **Dead zone = guaranteed zero profit**

**Why this fails:**

- Time passing with no gain (opportunity cost)
- Margin tied up for nothing
- Better strategies exist (iron condors, calendars)

**Example mistake:**

- Stock at $100, ranged $95-$105 for months
- "I'll do a RR just because..."
- Stock stays $98-$102 for 60 days
- Result: $0 gain, capital tied up
- **Should have used neutral strategy instead**

**Rule:** Only use RR when you have STRONG directional conviction

### 2. Low Volatility Environments

**The problem:**

- VIX < 15
- Stock IV < 25%
- Skew minimal
- **No edge from skew**

**Why avoid:**

- Can't collect credit (premiums tiny)
- Pay debit for RR (not worth it)
- No skew arbitrage value
- Small moves unlikely to breach strikes

**Example:**

- Market calm, VIX at 12
- Stock at $100
- $95 put: $1.50, $105 call: $1.80
- Net debit: $0.30
- **Paying to get into position (bad)**
- Dead zone $95-$105.30
- Need huge move to profit
- **Not attractive risk/reward**

**Rule:** Wait for IV > 30% and IV rank > 40%

### 3. Against Strong Momentum

**Never fight the trend:**

**The disaster:**

- Stock in parabolic rally
- "It's overbought, I'll sell calls..."
- Sell calls, buy puts (bearish RR)
- Stock continues ripping
- **Unlimited losses**

**Example - The GME Mistake:**

- GME at $40, rallying
- "No way it goes higher..."
- Bearish RR: Sell $50 call, Buy $35 put
- GME goes to $400
- **Destroyed on short call**

**Rule:** Never use RR to fade momentum. Wait for trend break.

### 4. Insufficient Conviction

**The wishy-washy RR:**

- "I think maybe it goes up..."
- "Probably won't go down much..."
- Not strong conviction, just guessing
- **Recipe for losses**

**Why this fails:**

- RR requires HIGH conviction
- Unlimited risk on one side
- Dead zone opportunity cost
- Need to be RIGHT about direction
- **Weak conviction = wrong strategy**

**Example:**

- "AAPL might rally to $200..."
- But not really sure
- Enter bullish RR anyway
- AAPL consolidates $180-$185
- Dead zone for 60 days
- **Wasted time and margin**

**Rule:** Only use RR when conviction is 8/10 or higher

### 5. Undercapitalized Accounts

**The margin problem:**

- RR requires margin for short option
- If put assigned, need $9,500 per contract
- Small account can't handle assignment
- **Forced liquidation risk**

**Example mistake:**

- $10,000 account
- Sell $95 put (bullish RR)
- Stock drops to $90
- Put assigned: Forced to buy 100 shares at $95 = $9,500
- Only have $10,000 total
- **Margin call, forced to sell at loss**

**Minimum account size:**

- For $100 stock RRs: $25,000+ account
- Need buffer for assignment
- Plus margin for other positions
- **Don't use RRs in small accounts**

**Rule:** Account size > 3x potential assignment value

### 6. Before Major Unknown Events

**The binary risk:**

- Earnings in 2 days (outcome unknown)
- FDA decision pending (unknown)
- Merger vote (uncertain)
- **Gap risk through both strikes**

**Why avoid:**

- Stock can gap huge either direction
- Both options can end up ITM (impossible normally)
- Or gap through dead zone instantly
- Unpredictable outcomes

**Example:**

- Biotech at $50
- FDA decision tomorrow
- Enter bullish RR: Sell $45 put, Buy $55 call
- FDA rejects → stock to $20
- **Put assigned at $45, stock worth $20**
- Loss: $25 per share = $2,500

**Rule:** Enter RR AFTER event passes, not before

---


---


---

## Economic

**Understanding what this strategy REALLY represents economically:**

### 1. The Core Economic Trade-Off

This IV strategy involves specific economic trade-offs around volatility exposure. The key is understanding what you're giving up versus what you're gaining in terms of implied volatility positioning.

**Economic equivalence:**

$$
\text{Strategy P\&L} = \text{IV Change Component} + \text{Term Structure Component} + \text{Skew Component}
$$

### 2. Why This IV Structure Exists Economically

Markets create these IV structures because different participants have different:
- Volatility expectations (near-term vs. long-term)
- Risk preferences (convexity vs. theta)
- Event views (known catalysts vs. unknown volatility)
- Hedging needs (portfolio protection vs. income generation)

### 3. The Volatility Risk Premium

Most IV strategies exploit the **volatility risk premium** - the empirical observation that:

$$
\text{Implied Volatility} > \text{Realized Volatility} \quad \text{(on average)}
$$

**Why this exists:**
1. **Insurance value:** Investors pay premium for protection
2. **Crash insurance:** Fear of tail events inflates IV
3. **Supply/demand:** More vol buyers than sellers
4. **Behavioral biases:** Overestimation of future volatility

### 4. Professional Institutional Perspective

Institutional traders view IV strategies as tools for:
1. **Volatility arbitrage:** Extracting the vol risk premium
2. **Term structure trading:** Exploiting mispricings across time
3. **Skew trading:** Capturing mispricing across strikes
4. **Surface arbitrage:** Finding no-arbitrage violations

Understanding the economic foundations helps you recognize when IV offers genuine edge versus when market pricing is fair.


## Practical Guidance

**Step-by-step implementation framework:**

### 1. Step 1

**Before entering, evaluate:**

1. **IV level analysis:**
   - Current IV percentile (IVP) or IV rank (IVR)
   - Is IV historically high or low?
   - IV vs. realized volatility spread

2. **Term structure analysis:**
   - Shape of vol term structure (contango/backwardation)
   - Front month vs. back month IV relationship
   - Event-driven distortions in term structure

3. **Skew analysis:**
   - Put vs. call IV differential
   - Shape of vol smile/smirk
   - Unusual skew steepness

4. **Upcoming events:**
   - Earnings announcements
   - Fed meetings, economic data
   - Product launches, regulatory decisions

### 2. Step 2

**Enter this strategy when:**
- [Specific IV conditions]
- [Term structure requirements]
- [Skew positioning]
- [Time to event/expiration]

**Avoid this strategy when:**
- [Unfavorable IV environment]
- [Wrong term structure shape]
- [Insufficient IV edge]
- [Event risk too high]

### 3. Step 3

**Calculate maximum position size:**

$$
\text{Max Contracts} = \frac{\text{Portfolio} \times \text{Risk\%}}{\text{Max Loss Per Contract}}
$$

**For IV strategies, consider:**
- Vega exposure limits ($ per 1% IV move)
- Theta collection goals ($ per day target)
- Gamma risk near expiration
- Capital at risk for defined-risk strategies

**Conservative sizing:**
- Max vega: $100-200 per 1% IV move per $10k capital
- Max theta: $20-50 per day per $10k capital
- Risk 1-2% on undefined risk strategies
- Risk 2-5% on defined risk strategies

### 4. Step 4

**Best practices:**

1. **IV analysis first:** Check IV percentile before entry
2. **Liquidity check:** Ensure tight bid-ask spreads
3. **Multi-leg orders:** Enter complete structure as one order
4. **Timing considerations:** 
   - Sell vol when IV elevated (IVR > 50)
   - Buy vol when IV depressed (IVR < 30)
   - Avoid entering right before events (IV usually elevated)

**Entry checklist:**
- [ ] IV percentile checked
- [ ] Term structure analyzed
- [ ] Liquidity verified (bid-ask < 10%)
- [ ] Position sized appropriately
- [ ] Greeks calculated (delta, vega, theta, gamma)
- [ ] Max loss understood
- [ ] Exit plan defined

### 5. Step 5

**Active management rules:**

**IV monitoring:**
- Track IV daily (minimum)
- Monitor IV percentile changes
- Watch term structure shifts
- Alert on IV expansion/contraction

**Profit targets:**
- **For short vol:** Close at 50-75% of max profit
- **For long vol:** Take profit at 100-200% gain
- **For term structure:** Close when term structure normalizes

**Loss limits:**
- **For short vol:** Close at 2-3x credit received
- **For long vol:** Cut at 50% loss
- **Time stop:** Exit if 50% of time passed with no favorable IV move

**Adjustment triggers:**
- IV percentile moves 20+ points
- Term structure inverts unexpectedly
- Underlying makes large move (>2 SD)
- Event announced/cancelled

### 6. Step 6

**When to adjust:**

**For short vol strategies:**
- Stock moves significantly against position
- IV expanding beyond entry level
- Risk of max loss approaching

**How to adjust:**
- Roll out in time (collect more theta)
- Roll strikes (move to new delta)
- Convert to different structure (spread to iron condor)
- Close and reenter at better strikes

**For long vol strategies:**
- IV not expanding as expected
- Theta burn exceeding plan
- Realized vol lower than expected

**How to adjust:**
- Scale into more contracts if IV crashes
- Roll to longer dated (reduce theta)
- Take partial profits on IV spikes
- Convert to calendar (neutralize theta)

### 7. Step 7

**Track every trade:**
- Entry IV level and percentile
- Term structure shape at entry
- Vega, theta, gamma at entry
- Days to expiration
- P&L by component (vega, theta, gamma)
- Actual IV vs. entry IV
- Lessons learned

**Quarterly review:**
- Win rate by IV percentile
- P&L by term structure shape
- Best entry IV conditions
- Common mistakes

### 8. Common Execution Mistakes to Avoid

1. **Selling vol at low IV** - IVR < 30 usually poor for short vol
2. **Buying vol at high IV** - IVR > 70 often too expensive for long vol
3. **Ignoring term structure** - Don't sell front month if in backwardation
4. **Over-leveraging vega** - Too much vega exposure can blow up account
5. **Holding through earnings** - IV crush destroys long vol positions
6. **Not taking profits** - Greed kills short vol profits
7. **Fighting IV trends** - IV regimes can persist
8. **Ignoring skew** - Put skew can make bearish trades expensive

### 9. Professional Implementation Tips

**For volatility selling (short vega):**
- Enter when IVR > 50, ideally > 70
- Target 60-70% probability of profit
- Close at 50% of max profit
- Use mechanical stops (2x credit)

**For volatility buying (long vega):**
- Enter when IVR < 30
- Need catalyst for IV expansion
- Take profits quickly on IV spikes
- Cut losses at 50% if IV doesn't cooperate

**For term structure trades:**
- Understand event calendar
- Check historical term structure patterns
- Monitor roll dynamics
- Scale positions gradually

**For skew trades:**
- Understand why skew exists in that stock
- Check historical skew patterns
- Combine with directional view
- Monitor skew changes daily


## Common Mistakes Beginners Make

### 1. Using RR Without Strong Conviction

**The casual RR:**

- "I'll try a risk reversal..."
- No real conviction, just experimenting
- Stock goes nowhere (dead zone)
- Opportunity cost kills returns

**The mistake:**

- RR is NOT a neutral strategy
- Requires HIGH conviction (8/10+)
- Otherwise dead zone wastes time
- **Weak conviction = wrong tool**

**Example:**

- "AAPL probably goes up..."
- Enter bullish RR half-heartedly
- AAPL trades $178-$183 for 60 days
- Dead zone: $175-$190
- Result: $0 gain, margin tied up
- **Should have used iron condor or nothing**

**The fix:**

- Only use RR when very high conviction
- Ask: "Would I bet $10,000 on this direction?"
- If no, don't use RR
- **High conviction = RR, low conviction = skip**

### 2. Ignoring the Dead Zone

**The blindness:**

- Focus only on "unlimited upside"
- Forget about dead zone completely
- Don't realize opportunity cost
- Shocked when no profit in range

**The mistake:**

- Dead zone can be 10-20% wide
- Stock spends MOST time in ranges
- If stock in dead zone, you make $0
- **Meanwhile stock owners making money**

**Example:**

- Bullish RR: $95 put / $105 call
- Stock rallies $100 → $103 (+3%)
- Stock owner: +$300 profit
- RR holder: $0 profit (still in dead zone)
- **Lost $300 opportunity**

**The fix:**

- Calculate dead zone size upfront
- Understand you make $0 in this range
- Consider tighter strikes if conviction high
- **Accept dead zone cost or don't use RR**

### 3. Underestimating Assignment Risk

**The surprise:**

- Short put goes ITM
- "It'll come back..."
- Expiration arrives
- **Assigned 100 shares, didn't expect it**

**The mistake:**

- ITM options get assigned at expiration
- Forced to buy 100 shares at strike
- Ties up $9,500+ in capital
- May trigger margin call

**Example:**

- Bullish RR: Sell $95 put
- Stock drops to $92 at expiration
- Put expires ITM
- **Assigned:** Forced to buy 100 shares at $95
- Current value: $92
- Instant loss: $300
- Plus: $9,500 capital now tied up in stock

**The fix:**

- Close ITM short options before expiration
- Don't let them expire ITM
- If ITM week before expiration, close entire RR
- **Never let assignment happen unintentionally**

### 4. Fighting the Thesis When Wrong

**The stubbornness:**

- Bullish RR established
- Market turns bearish (Fed hawkish)
- Original thesis broken
- "But I was right before..."
- Hold position anyway
- **Losses mount**

**The mistake:**

- Thesis invalidated, but ego won't exit
- Hope for reversal instead of adapting
- Unlimited risk starts materializing
- Small loss becomes huge loss

**Example:**

- Bullish RR on growth stocks
- Fed announces faster rate hikes
- Growth stocks will suffer (clear)
- "But my technical analysis said..."
- Hold position
- **Stock drops 20%, losses massive**

**The fix:**

- Monitor thesis constantly
- If fundamentally broken, exit immediately
- Small loss acceptable, big loss not
- **Flexibility > being right**

### 5. Overleveraging with Multiple RRs

**The greed:**

- "RRs are free, I'll do 10 of them!"
- Open many RRs on correlated stocks
- All bullish (same direction)
- Market corrects
- **All positions hit max loss simultaneously**

**The mistake:**

- "Free" doesn't mean riskless
- Multiple RRs = multiplied risk
- Correlation ignored
- Portfolio-level risk explosion

**Example:**

- $50,000 account
- Open 10 bullish RRs on tech stocks (AAPL, MSFT, GOOGL, etc.)
- Each: Sell $95 put on $100 stock
- Tech sector crashes -15%
- All puts assigned
- Need $95,000 to buy 1,000 shares
- **Account blown up, margin call**

**The fix:**

- Max 2-3 RRs at a time
- Diversify across sectors
- Mix bullish and bearish
- **Never concentrate in one direction**

### 6. Not Checking Skew Before Entry

**The blindness:**

- Just enter symmetric strikes
- Don't check IV by strike
- Miss opportunity for credit
- Or pay unnecessary debit

**The mistake:**

- Could have collected credit with asymmetric strikes
- Instead paid debit with symmetric strikes
- Lost arbitrage value from skew
- **Left money on table**

**Example:**

**Without checking skew:**

- Stock at $100
- Sell $95 put for $3.50 (didn't check IV)
- Buy $105 call for $4.00 (didn't check IV)
- Net debit: $0.50

**After checking skew:**

- $92 put has IV = 38%, costs $4.50 (expensive!)
- $110 call has IV = 30%, costs $4.00 (cheap!)
- Better strikes: Sell $92 put, Buy $110 call
- Net credit: $0.50

**Lost $1.00 per share by not optimizing!**

**The fix:**

- Always check IV by strike
- Use IV rank/percentile
- Sell high IV, buy low IV
- **Optimize for credit collection**

### 7. Holding Through Expiration

**The danger:**

- Position near expiration
- Short option slightly ITM
- "Maybe it'll go back OTM..."
- Expires ITM
- **Assignment!**

**The mistake:**

- Gamma explodes near expiration
- Small moves have huge impact
- Assignment risk very high
- Should have closed earlier

**Example:**

- Bullish RR with $95 put
- Stock at $94.50 with 3 days to expiration
- "It might rally back above $95..."
- Expires at $94.20
- **Put assigned, forced to buy at $95**

**The fix:**

- Close all RRs at 7-14 DTE
- Never hold through expiration week
- Gamma risk too high
- **Take small loss/gain, exit clean**

---

## Advanced Concepts

### 1. The Skew Trading RR

**Using RR purely to trade volatility skew:**

**Concept:**

- Not primarily directional
- Exploit extreme skew
- Collect large credit
- Close when skew normalizes

**Example:**

- Market panic, VIX spikes to 40
- Put skew extreme
- Stock at $100
- $90 put: IV = 60%, costs $8.50
- $110 call: IV = 40%, costs $5.00
- **Enter RR for $3.50 credit**

**The bet:**

- Not necessarily bullish on stock
- Bullish on skew normalization
- When panic fades, skew contracts
- RR value drops even if stock flat

**Management:**

- Enter during panic (VIX >30)
- Exit when skew normalizes (VIX <20)
- Don't hold for directional move
- **Pure volatility arbitrage**

### 2. The Collar (RR + Stock)

**Combining RR with stock ownership:**

**Structure:**

- Own 100 shares
- Sell OTM call (like bearish RR)
- Buy OTM put (like bullish RR)
- = Zero-cost hedge

**Example:**

- Own 100 shares AAPL at $180
- Sell $190 call for $4.00
- Buy $170 put for $4.00
- Net cost: $0

**Effect:**

- Downside protected at $170
- Upside capped at $190
- Free protection (collar costs $0)
- **Insurance without premium**

**When to use:**

- Worried about downside
- Willing to cap upside
- Want to hold stock
- **Risk management tool**

### 3. The Ratio Risk Reversal

**Unequal number of contracts:**

**Structure:**

- Sell 2 puts
- Buy 1 call
- Collect large credit
- **Unlimited downside risk if stock crashes**

**Example:**

- Sell 2 × $95 puts for $7.00 total
- Buy 1 × $105 call for $4.00
- Net credit: $3.00

**The bet:**

- Very bullish
- Stock won't crash
- Extra credit worth the risk
- **Extremely aggressive**

**Danger:**

- Below $95, losing on TWO naked puts
- Essentially 2x leverage on downside
- **For experienced traders only**

### 4. Legging Into Risk Reversals

**Building RR in two steps:**

**Strategy:**

- Don't enter both sides simultaneously
- Time the entries separately
- Potentially improve pricing

**Example:**

**Step 1:** Stock pulling back
- Enter long call first at $105 for $3.50
- Wait for bounce

**Step 2:** Stock bounces
- Now sell put at $95 for $4.00
- Net credit: $0.50
- **Better execution than simultaneous**

**Pros:**

- Better fills possible
- Flexibility in timing
- Can abandon if market changes

**Cons:**

- Exposed to market move between legs
- May not complete second leg
- Requires active monitoring

**Risk:**

- If stock gaps after leg 1, leg 2 pricing changes
- Could end up with orphan position
- **Only for active traders**

### 5. The Earnings Risk Reversal

**Special application around earnings:**

**Strategy:**

- Enter AFTER earnings announcement
- Stock has moved, IV crushed
- Direction clarified
- RR captures continued move

**Example:**

- NFLX earnings beat
- Stock gaps from $380 → $410
- IV crushed from 60% → 35%
- Direction: Bullish confirmed
- **Enter bullish RR:**

  - Sell $395 put for $8 (still elevated IV)
  - Buy $425 call for $7
  - Net credit: $1

**Why it works:**

- Event risk gone
- IV still elevated but dropping (helps)
- Trend established
- **Capture post-earnings drift**

**Timing:**

- Enter 1-2 days after earnings
- Not before (binary risk)
- Not week after (IV already normalized)

### 6. The Delta-Hedged RR

**Advanced: Using RR for market-neutral skew trade:**

**Concept:**

- Enter RR
- Hedge the delta with stock
- Pure skew play, no directional risk

**Example:**

- Stock at $100
- Enter bullish RR (delta +0.50)
- Short 50 shares (delta -0.50)
- **Net delta: 0**

**The bet:**

- Not directional
- Profit from skew normalization
- Hedge protects from stock moves
- **Pure volatility arbitrage**

**For:**

- Professional traders
- Large accounts
- Access to short stock
- **Complex, not for beginners**

---

## Risk Management Rules

### 1. Position Sizing for Risk Reversals

**More conservative than other strategies:**

$$
\text{Max RRs} = \frac{\text{Account Size}}{10 \times \text{Stock Price}}
$$

**Example:**

- $100,000 account
- Stock at $100
- Max RRs: $100,000 / (10 × $100) = 10 contracts

**But this is absolute maximum. Recommended:**

**Conservative approach:**

- Max 2-3 RRs at a time
- Max 30% of account in RR margin
- Never all same direction
- **Diversification critical**

**Account size requirements:**

| Account Size | Max RRs (per $100 stock) | Reasoning |
|-------------|------------------------|-----------|
| <$25,000 | 0-1 | Assignment risk too high |
| $25,000-$50,000 | 1-2 | Limited capital for assignment |
| $50,000-$100,000 | 2-4 | Adequate buffer |
| >$100,000 | 3-6 | Sufficient capital |

### 2. Diversification Rules

**Critical for RRs:**

**Directional diversification:**

- Max 60% in one direction (bullish or bearish)
- Ideally 50/50 split if trading both
- Example: 2 bullish RRs, 2 bearish RRs

**Sector diversification:**

- Max 1-2 RRs per sector
- Avoid correlation
- Example: 1 tech, 1 healthcare, 1 energy

**Strike diversification:**

- Vary strike distances
- Some conservative (wide strikes)
- Some aggressive (tight strikes)
- Different assignment probabilities

**Time diversification:**

- Stagger expirations
- Not all expiring same month
- Continuous rolling approach

### 3. The Two-Level Stop Loss System

**RRs need special stops:**

### 4. Level 1

**Trigger:**

- Stock moved 50% toward short strike
- Or thesis shows cracks
- Or position down 25%

**Action:**

- Begin close monitoring
- Reevaluate conviction
- Prepare to exit

**Example - Bullish RR:**

- Sold $95 put
- Stock drops from $100 → $97.50
- Moved 50% toward strike
- **Alert triggered, monitor daily**

### 5. Level 2

**Trigger:**

- Stock within 2% of short strike
- Or thesis completely broken
- Or position down 50%
- Or <21 DTE with ITM short option

**Action:**

- **Close immediately**
- No waiting
- Accept loss
- Move on

**Example:**

- Stock at $96 (sold $95 put)
- Within $1 of strike
- 15 DTE remaining
- **Close NOW**

### 6. Assignment Prevention Protocol

**Never let assignment happen:**

**Rules:**

1. Close any ITM short option 7 days before expiration
2. If ITM at 21 DTE, close entire RR
3. Set price alerts at short strikes
4. Check positions daily last 2 weeks

**Assignment costs:**

- Ties up $9,500+ capital per contract
- Commission on stock purchase
- Forced to hold unwanted stock
- May trigger margin call
- **Avoid at all costs**

### 7. Portfolio-Level Risk

**Aggregate exposure limits:**

**Total RR exposure:**

- Max 30% of portfolio in RR margin
- Max 50% in any one direction
- Net delta: <±500 (like ±50 shares)

**Example $100,000 portfolio:**

- Max in all RRs: $30,000 margin
- Max bullish exposure: $50,000 (5 RRs on $100 stock)
- Max bearish exposure: $50,000
- Keep $70,000 in reserve

**Correlation check:**

- Calculate portfolio net delta weekly
- If >±500, reduce exposure
- Rebalance toward neutral

### 8. The Conviction Checklist

**Before entering ANY RR, verify:**

☐ Conviction level 8/10 or higher
☐ Specific thesis (not vague)
☐ Catalyst or technical support
☐ IV rank > 40% (preferably >50%)
☐ Skew favorable for credit
☐ Account can handle assignment
☐ No major event in next 30 days
☐ Clear exit plan established

**If any checkbox fails, DON'T enter RR**

---


---

## Common Mistakes

**The fatal errors that destroy risk reversal traders:**

### 1. Mistake #1

**The trap:**

**What traders do:**
```
Market environment:
- Stock at $100
- "Feels" like it might go up
- Conviction: 6/10 (weak)
- Think: "RR is zero cost, why not try?"

Enter bullish RR:
- Sell $95 put for $3.00
- Buy $105 call for $3.00
- Net: $0 cost
```

**Why it's wrong:**

**Risk reversal characteristics:**
- Unlimited downside risk (like owning stock)
- Unlimited upside potential (like owning stock)
- But: Dead zone $95-$105 (no profit in middle)
- **Need STRONG move to profit**

**With 6/10 conviction:**
```
Probability outcomes:
- 30% stock rallies above $105 (profit)
- 40% stock stays $95-$105 (breakeven, wasted time)
- 30% stock drops below $95 (unlimited loss)

Expected value:
- Best case: +$2,000 (30% chance)
- Dead zone: $0 (40% chance)
- Bad case: -$5,000 (30% chance on -$5 move)

EV = (0.30 × $2,000) + (0.40 × $0) + (0.30 × -$5,000)
   = $600 - $1,500 = -$900

Negative EV trade!
```

**With 8+/10 conviction:**
```
Probability outcomes (when conviction justified):
- 60% stock rallies above $105 (profit)
- 25% stock stays $95-$105 (breakeven)
- 15% stock drops below $95 (loss)

Expected value:
- Best case: +$2,000 (60% chance)
- Dead zone: $0 (25% chance)
- Bad case: -$5,000 (15% chance)

EV = (0.60 × $2,000) + (0.25 × $0) + (0.15 × -$5,000)
   = $1,200 - $750 = +$450

Positive EV trade!
```

**The disaster:**

```
Weak conviction (6/10) trade progression:

Week 1-2: Stock at $98-$102 (dead zone)
- No profit
- Time passing
- Opportunity cost building

Week 3: Stock drops to $94
- Short put getting close to ITM
- Start worrying
- "Maybe I was wrong?"

Week 4: Stock at $91
- Short put ITM
- Down -$4 per share = -$400
- Conviction was never strong enough
- **Should never have entered**

Final: Close at -$400 loss
Could have been avoided entirely with 8+ conviction rule
```

**The fix:**

**Conviction requirements for RR:**

```
Minimum conviction scale:

8/10: Acceptable for RR
- Clear thesis
- Multiple supporting factors
- High probability of strong move
- Comfortable with risk

9/10: Ideal for RR
- Very strong conviction
- Overwhelming evidence
- Willing to bet account on it
- Perfect setup

<8/10: DO NOT TRADE RR
- Use vertical spread instead (defined risk)
- Or long call/put (limited loss)
- Or skip the trade
- Never RR with weak conviction
```

**Conviction checklist:**

```
Before entering RR, verify:
[ ] Fundamental analysis supports move
[ ] Technical setup confirms direction
[ ] Catalyst identified for move
[ ] Risk/reward compelling
[ ] Comfortable with unlimited risk
[ ] Multiple timeframe confirmation
[ ] Willing to hold through volatility
[ ] Can size position appropriately

If any box unchecked: Conviction <8/10
Don't trade RR!
```

**Prevention:**
```
[ ] Rate conviction 1-10 before every RR
[ ] If <8: Don't enter (use different strategy)
[ ] Document conviction reasoning in journal
[ ] Review past RRs: Did conviction match outcome?
[ ] Remember: "Zero cost" ≠ "no risk"
```

### 2. Mistake #2

**The trap:**

**What traders do:**
```
Bullish RR:
- Stock at $100
- Sell $95 put
- Buy $105 call
- Dead zone: $95-$105 ($10 range)

Think: "Stock will rally above $105, easy!"
```

**Why it's wrong:**

**Dead zone reality:**

```
Stock movement probabilities (typical):
- Below $95: 20%
- $95-$105 (dead zone): 50%
- Above $105: 30%

Most likely outcome: DEAD ZONE (50%)
In dead zone: Zero profit, maximum time waste
```

**The mathematics:**

**Dead zone width vs. profitability:**

| Dead Zone Width | Stock Volatility | % Time in Dead Zone | Expected Value |
|----------------|------------------|---------------------|----------------|
| $5 (narrow) | 15% annual | 30% | Positive |
| $10 (normal) | 15% annual | 50% | Neutral/Negative |
| $15 (wide) | 15% annual | 65% | Very Negative |
| $20 (huge) | 15% annual | 75% | Terrible |

**Wider dead zone = higher probability of wasting time**

**The disaster:**

```
Month 1: Enter RR with $15 dead zone
- Stock at $100
- Sell $90 put, Buy $115 call
- Credit: $1.00 (small, from skew)

Week 1-4: Stock at $98-$108 (dead zone)
- Position value: +$50 (credit + small IV move)
- But: No meaningful profit
- Time: 4 weeks wasted

Month 2: Stock still at $102-$110 (dead zone)
- Position value: +$100 total
- 2 months of capital tied up
- Opportunity cost: Could have made $500 in other trades

Month 3 (approaching expiration):
- Stock at $105 (dead zone)
- Position expires worthless (except small credit)
- Total profit: $100
- Time wasted: 90 days
- ROI: Terrible (on opportunity cost basis)

Compare to:
- Narrower dead zone ($5 wide)
- Higher probability of profiting
- Less time wasted in "no man's land"
```

**The fix:**

**Optimal dead zone sizing:**

```
Dead zone width formula:

Maximum dead zone = Stock Price × (Expected Daily Move × √Days)

For 30-60 DTE:
- Low volatility stock (15% IV): 5-7% dead zone
- Medium volatility (25% IV): 7-10% dead zone  
- High volatility (40% IV): 10-15% dead zone

Example at $100 stock, 25% IV, 60 DTE:
Max dead zone = $100 × 0.10 = $10
Strikes: $95 put, $105 call ✓

Avoid: $90 put, $110 call (too wide!)
```

**Strike selection rules:**

```
For bullish RR:
Short put: 1-1.5 standard deviations OTM
Long call: 1-1.5 standard deviations OTM

This creates:
- Moderate dead zone (not too wide)
- Reasonable chance to profit
- Acceptable credit from skew

Don't:
- Make dead zone >15% of stock price
- Put strikes too far OTM
- Accept tiny credit for huge dead zone
```

**Prevention:**
```
[ ] Calculate dead zone width before entry
[ ] Max dead zone: 10% of stock price
[ ] If dead zone >10%: Tighten strikes
[ ] Check historical price movement (past 60 days)
[ ] If stock rangebound: Avoid RR entirely
[ ] Remember: Dead zone = dead money
```

### 3. Mistake #3

**The trap:**

**What traders do:**
```
Bullish RR:
- Stock at $100
- Sell $95 put, Buy $105 call

Week 3: Stock drops to $94
- Short $95 put now ITM
- Think: "It will bounce back"
- Don't close

Week 4: Stock at $91
- Deep ITM on put
- Down -$4 = -$400
- Still hoping
- **Still not closing**
```

**Why it's DISASTROUS:**

**Unlimited loss acceleration:**

```
Short put behavior once ITM:

At strike ($95):
- Delta: -0.50
- For each $1 drop: Lose $50

$1 below strike ($94):
- Delta: -0.65
- For each $1 drop: Lose $65

$2 below strike ($93):
- Delta: -0.75
- For each $1 drop: Lose $75

$5 below strike ($90):
- Delta: -0.95
- For each $1 drop: Lose $95

Losses accelerate geometrically!
```

**The disaster:**

```
Timeline of ignoring breach:

Day 1: Stock at $94 (put strike $95)
- Loss: -$100
- Think: "Small loss, will recover"
- Decision: Hold

Day 5: Stock at $92
- Loss: -$300
- Think: "Oversold, must bounce"
- Decision: Still hold

Day 10: Stock at $89
- Loss: -$600
- Now panicking
- Think: "Already down so much, might as well hold"
- **Mistake: Sunk cost fallacy**

Day 15: Stock at $85
- Loss: -$1,000
- Finally capitulate
- Close at massive loss

If had closed at $94 (Day 1):
- Loss: -$100
- Saved: $900
- Just by acting fast!
```

**Why traders don't close:**

1. **Hope:**
   - "Stock will bounce"
   - "Just temporary"
   - "Can't accept loss"

2. **Sunk cost fallacy:**
   - "Already down $300"
   - "Might as well hold"
   - "Could recover"

3. **Denial:**
   - "Thesis still valid"
   - "Market wrong, I'm right"
   - "Different this time"

4. **Ego:**
   - "Can't be wrong"
   - "Traders don't lose"
   - "Must prove myself right"

**The fix:**

**Immediate exit rules:**

```
Rule 1: CLOSE immediately when short strike breached
- No exceptions
- No hoping
- No waiting
- Exit NOW

Rule 2: If short strike tested (within 1%)
- Start preparing exit
- Tighten stop
- Evaluate thesis
- Likely exit soon

Rule 3: Loss limits (redundant safety)
- Max loss: 2× dead zone width
- Example: $10 dead zone → -$20 max loss
- If hit: Auto-exit

Rule 4: Time-based review
- If not profitable after 50% of time
- Close and redeploy
- Don't wait for miracle
```

**Mechanical exit system:**

```python
def should_exit_RR(stock_price, short_strike, strike_type, dead_zone_width):
    """
    Determine if should exit risk reversal
    """
    if strike_type == "put":
        # Bullish RR
        if stock_price <= short_strike:
            return True, "Short put BREACHED - EXIT NOW"
        elif stock_price <= short_strike * 1.01:
            return True, "Short put tested - EXIT SOON"
            
    elif strike_type == "call":
        # Bearish RR
        if stock_price >= short_strike:
            return True, "Short call BREACHED - EXIT NOW"
        elif stock_price >= short_strike * 0.99:
            return True, "Short call tested - EXIT SOON"
    
    return False, "Position OK"

# Example
# Bullish RR
# Stock at $94
# Result
# ACTION
```

**Prevention:**
```
[ ] Set alert at short strike price
[ ] Set alert at short strike + 1%
[ ] Pre-commit to exit if breached
[ ] No exceptions for "special circumstances"
[ ] Close within 1 hour of breach
[ ] Review breaches monthly: Did I exit fast enough?
[ ] Remember: First loss is best loss
```

### 1. Mistake #4

**The trap:**

**What traders think:**
```
Risk reversal costs: $0
Think: "No money at risk! Can do more!"

Position sizing:
- Normally trade 1-2 contracts
- But RR is "free"
- Enter 10 contracts!
- "Why not? It's zero cost!"
```

**Why it's CATASTROPHIC:**

**Hidden leverage:**

```
Apparent cost: $0
Real risk: UNLIMITED

10 contract RR = controlling $100,000 of stock
For: $0 upfront
This is: INFINITE leverage!

Compare:
- Buying 1,000 shares: $100,000 capital
- 10 RR contracts: $0 capital, same exposure
- Leverage: ∞:1 (literally infinite)
```

**The mathematics:**

**True risk calculation:**

```
Bullish RR: Sell $95 put, Buy $105 call

Assignment risk calculation:
- If stock drops to $85 (10% decline)
- Short put assigned: Must buy at $95
- 10 contracts = 1,000 shares
- Cost: 1,000 × $95 = $95,000
- Current value: 1,000 × $85 = $85,000
- Loss: -$10,000

Plus: Don't have $95,000!
- Must use margin
- Margin call likely
- Forced to close at worst price
- Real loss: -$12,000+ (with margin fees)

"Zero cost" position created $12,000 loss!
```

**The disaster:**

```
Account: $50,000

Enter 10 RR contracts (bullish):
- Think: "Zero cost, no risk!"
- Assignment risk: $95,000
- Real exposure: 2× account size

Week 1: Stock drops 5% to $95
- Short put at strike
- Nervous but holding

Week 2: Stock drops to $90
- Short put deep ITM
- Loss: -$5,000 (10 contracts × $500)
- Still have long calls (worthless)
- Net: -$5,000 (10% of account!)

Week 3: Stock at $85
- Approaching assignment
- Loss: -$10,000 (20% of account!)
- Margin call coming
- Panic: Must close

Exit forced at $85:
- Total loss: -$10,000
- Account: $50,000 → $40,000
- Drawdown: -20%
- Recovery needed: 25% gain

If had sized properly (2 contracts):
- Loss: -$2,000 (4% of account)
- Still alive, can recover
- Manageable drawdown

Oversizing multiplied disaster 5×!
```

**The fix:**

**Proper RR position sizing:**

```
Formula 1: Assignment-based sizing

Max contracts = (Account × 0.50) / (Short Strike × 100)

Example:
$50,000 account
Short $95 put
Max = ($50,000 × 0.50) / ($95 × 100)
    = $25,000 / $9,500
    = 2.63 → 2 contracts

Rule: Never use more than 50% of account for assignment risk

Formula 2: Loss-based sizing (more conservative)

Max contracts = (Account × 0.02) / Expected Loss Per Contract

Example:
$50,000 account
Expected max loss: $1,000 per contract (10% move)
Max = ($50,000 × 0.02) / $1,000
    = $1,000 / $1,000
    = 1 contract

Rule: Risk only 2% of account per trade
```

**Position limits:**

```
Conservative (recommended):
- Max 2% of account at risk
- 1-2 contracts for $50k account
- 3-5 contracts for $100k account

Moderate:
- Max 5% of account at risk  
- 2-4 contracts for $50k account
- 5-10 contracts for $100k account

Aggressive (dangerous):
- Max 10% of account at risk
- 4-6 contracts for $50k account
- Only for highest conviction (9-10/10)

Never:
- >10% of account at risk
- Position size that can't handle assignment
- "All in" because "zero cost"
```

**Prevention:**
```
[ ] Calculate assignment risk before entry
[ ] Max position: 50% of account in assignment risk
[ ] Alternatively: Max 2% risk per trade
[ ] "Zero cost" does NOT mean "no risk"
[ ] Size RR like you're buying stock
[ ] Keep 50%+ cash for assignments
[ ] Remember: Leverage kills accounts
```

### 2. Mistake #5

**The trap:**

**What traders do:**
```
Earnings in 3 days:
- Stock at $100
- "Bullish on earnings"
- Enter bullish RR

Think: "If earnings good, stock gaps to $110!"
       "RR will print money!"
```

**Why it's a GAMBLE (not trade):**

**Binary event characteristics:**

```
Earnings outcomes:
- Beat: Stock gaps +8% → Win big
- Meet: Stock flat → Dead zone
- Miss: Stock gaps -15% → Disaster

Probabilities (roughly):
- Beat: 33%
- Meet: 33%
- Miss: 33%

This is literally a coin flip!
No edge, pure gambling
```

**The disaster:**

```
Pre-earnings RR (bullish):
- Stock at $100
- Sell $95 put for $4.00 (IV 60%)
- Buy $105 call for $4.00 (IV 55%)
- Net: $0 cost

Expectations:
- Beat → Stock to $110 → +$500 profit
- Meet → Stock to $102 → Small profit
- Miss → Stock to $92 → -$300 loss

Actual earnings result: MISS
- Revenue miss, guidance cut
- Stock gaps to $85 (down 15%!)
- Short $95 put: Deep ITM
- Long $105 call: Worthless

Day after earnings:
- Stock at $85
- Short put loss: -$10 per share
- Long call: Worthless
- Total: -$1,000 (per contract)

Plus: IV crush (60% → 30%)
- Short put IV drops (helps)
- But delta loss overwhelms
- Net: Still massive loss

Expected worst case: -$300
Actual loss: -$1,000
3× worse than planned!

Binary events are unpredictable
Gaps can be massive
RR amplifies the disaster
```

**Why traders do it:**

1. **Greed:**
   - "Big move opportunity!"
   - "Can't miss it!"
   - "This is THE trade!"

2. **Overconfidence:**
   - "I know earnings will beat"
   - "My analysis is better"
   - "Market doesn't understand"

3. **FOMO:**
   - "Everyone else trading it"
   - "Miss out on gains"
   - "Easy money"

4. **Ignorance:**
   - Don't understand IV crush
   - Don't realize gaps bypass strikes
   - Don't know binary risk

**The fix:**

**Event avoidance rules:**

```
NEVER trade RR around:

1. Earnings (0-7 days before)
   - IV elevated (priced in)
   - Gap risk massive
   - Binary outcome
   - Wait until AFTER

2. FDA decisions (biotech)
   - Approval: Stock +100%
   - Rejection: Stock -80%
   - Pure lottery
   - Avoid entirely

3. Fed meetings (major decisions)
   - Market-wide gap risk
   - Unpredictable reaction
   - Wait for clarity

4. Product launches (Apple, Tesla)
   - Reception unknown
   - Stock can gap either way
   - Wait for results

5. Legal rulings
   - Binary outcomes
   - Massive gaps possible
   - Too risky

6. Geopolitical events
   - War, elections, etc.
   - Market chaos
   - Avoid uncertainty
```

**Safe timing:**

```
AFTER events:

1-2 days after earnings:
- IV crushed back to normal
- Stock found new level
- Direction clearer
- NOW consider RR (if still bullish/bearish)

After FDA/catalyst:
- Dust settled
- Stock stabilized
- New trend forming
- NOW can trade

Advantage:
- Less uncertainty
- Normal volatility
- Better risk/reward
- Actual edge (not gambling)
```

**Prevention:**
```
[ ] Check earnings calendar before EVERY RR
[ ] No RR within 7 days of earnings
[ ] No RR before any binary event
[ ] If event announced after entry: Close immediately
[ ] Wait 1-2 days after event before re-entering
[ ] Remember: Events = gambling, not trading
```

### 3. Mistake #6

**The trap:**

**What traders do:**
```
Want bullish exposure:

Option A: Buy call
- Cost: $5.00
- Need stock to move

Option B: Bullish RR
- Sell $95 put: IV 45%, get $4.50
- Buy $105 call: IV 35%, pay $4.50
- Net: $0

Think: "Both zero cost, same thing"
```

**Why it's wrong:**

**Missing the skew edge:**

```
Put skew exists: Puts trade at higher IV than calls

Normal market:
- $95 put: IV 45% (elevated)
- $105 call: IV 35% (normal)
- Difference: 10 points

This creates OPPORTUNITY:
- Sell expensive put (45% IV)
- Buy cheap call (35% IV)
- Collect CREDIT from skew!

Better RR structure:
- Sell $95 put for $5.00 (high IV)
- Buy $105 call for $4.00 (low IV)
- **Net credit: $1.00 ($100)**

Same structure, but got PAID $100!
```

**The mathematics:**

**Skew value:**

```
Stock at $100

Scenario A: Ignoring skew (balanced IV)
- Sell $95 put at 40% IV: $4.50
- Buy $105 call at 40% IV: $4.50
- Credit: $0

Scenario B: Using skew
- Sell $95 put at 50% IV: $6.00
- Buy $105 call at 35% IV: $4.00
- Credit: $2.00 ($200!)

Extra edge: $200 from skew
This is FREE MONEY from market mispricing!
```

**The disaster (missing skew):**

```
Trader 1 (ignores skew):

Enters RR at balanced strikes:
- Zero credit
- Stock must move significantly to profit
- Dead zone: $95-$105
- Needs >5% move minimum

Result:
- Stock rallies to $107
- Profit: $200 (2% move into profit zone)

Trader 2 (uses skew):

Enters RR collecting $2.00 credit:
- Got paid $200 upfront
- Same strikes
- Same dead zone

Result:
- Stock rallies to $107
- Profit: $200 (from move) + $200 (credit)
- Total: $400

Difference: 2× profit for same trade!
Skew awareness doubled returns!
```

**How to check skew:**

```
Before entering RR:

1. Look up IVs:
   - Check put IV at your strike
   - Check call IV at your strike
   - Calculate difference

2. Skew opportunity:
   - Put IV - Call IV > 5 points: Good
   - Put IV - Call IV > 10 points: Excellent
   - Put IV - Call IV < 3 points: Poor, skip

3. Adjust strikes if needed:
   - If skew poor at chosen strikes
   - Move strikes to find better skew
   - Optimize for maximum credit

Example:
- Original: $95 put (IV 42%), $105 call (IV 38%) → 4 point skew
- Better: $92 put (IV 48%), $108 call (IV 36%) → 12 point skew
- Choose better skew strikes!
```

**The fix:**

**Skew exploitation rules:**

```
For bullish RR:
- Target put IV > call IV by 5+ points
- Collect credit, don't pay debit
- Minimum credit: $0.50 per spread
- Ideal credit: $1.00-$2.00

For bearish RR:
- Sometimes call IV > put IV (rare)
- Same principles apply
- Sell expensive, buy cheap

For any RR:
- Always check skew first
- Optimize strikes for credit
- Free money from market inefficiency
- Don't leave it on table!
```

**Skew checking tool:**

```python
def analyze_skew(put_strike, put_iv, call_strike, call_iv):
    """
    Check if skew provides edge for RR
    """
    skew = put_iv - call_iv
    
    if skew > 10:
        return "EXCELLENT", f"Put IV {skew} points higher - strong credit"
    elif skew > 5:
        return "GOOD", f"Put IV {skew} points higher - decent credit"
    elif skew > 2:
        return "ACCEPTABLE", f"Minimal skew advantage"
    else:
        return "POOR", f"No skew edge - consider different strikes"

# Example
# analyze_skew(95, 50, 105, 38)
# Result
```

**Prevention:**
```
[ ] Always check IV of both strikes before entry
[ ] Calculate skew differential (put IV - call IV)
[ ] Minimum skew: 3 points for RR
[ ] Prefer skew >5 points
[ ] Adjust strikes to optimize skew
[ ] If no skew: Consider different strategy
[ ] Remember: Skew = free edge, use it!
```

### 1. Mistake #7

**The trap:**

**What traders think:**
```
Covered call mentality:
- Sell call, collect premium
- Hold stock
- Manage passively
- Roll if needed

Apply to RR:
- Enter RR, collect credit
- Set and forget
- "It'll work out"
- Check once a week
```

**Why it's WRONG:**

**Key differences:**

```
Covered call:
- Defined max loss (stock to $0)
- Gradual movement (-$1/day typical)
- Time to react (days/weeks)
- Can hold through volatility
- Assignment = OK (wanted to sell anyway)

Risk reversal:
- UNLIMITED loss potential
- Can gap overnight (earnings, news)
- No time to react (gaps bypass stops)
- Cannot hold through volatility
- Assignment = DISASTER (don't have capital)

Management intensity:
- Covered call: Check 1-2× per week
- Risk reversal: Check DAILY minimum
```

**The disaster:**

```
Passive RR management:

Monday: Enter bullish RR
- Stock at $100
- Sell $95 put, Buy $105 call
- Credit: $1.00
- Set and forget

Tuesday-Thursday: Busy with work
- Don't check position
- "It's fine, stock stable"

Friday morning: Check position
- Stock gapped down to $88 overnight!
- Negative news (accounting issue)
- Short $95 put: -$7 ITM
- Loss: -$700 per contract

Shocked: "How did this happen?"
Reality: Didn't monitor, missed warning signs

If had checked daily:
- Wednesday: News leaked, stock $97
- Could have closed at -$200
- Instead: Closed at -$700
- Passive management cost $500!
```

**What active management catches:**

```
Daily monitoring catches:

1. Technical breaks:
   - Support level broken
   - Trend change
   - Exit before bigger move

2. News flow:
   - Company announcements
   - Sector weakness
   - Macro changes

3. Position changes:
   - Delta shifts
   - IV changes
   - Time decay

4. Conviction updates:
   - Thesis still valid?
   - New information?
   - Need to adjust?

Missing any = potential disaster
```

**The fix:**

**Active RR management:**

```
Daily routine (5-10 minutes):

Morning:
[ ] Check stock price vs. strikes
[ ] Check for overnight news
[ ] Verify thesis still intact
[ ] Calculate current P/L
[ ] Check days to expiration

Mid-day (if volatile):
[ ] Re-check price
[ ] Monitor any news
[ ] Be ready to act

Evening:
[ ] Log daily changes
[ ] Plan for tomorrow
[ ] Set alerts for next day

Weekly review:
[ ] Full position analysis
[ ] Greeks check
[ ] Thesis evaluation
[ ] Consider adjustments
```

**Alert system:**

```
Set multiple alerts:

Price alerts:
- Short strike price (critical)
- Short strike + 2% (warning)
- Long strike price (profit target)

News alerts:
- Company announcements
- Sector news
- Earnings date reminders

Time alerts:
- 30 DTE (start thinking exit)
- 21 DTE (exit zone)
- 7 DTE (must exit)

Multiple layers = safety net
```

**Prevention:**
```
[ ] Commit to daily monitoring
[ ] Set comprehensive alerts
[ ] Never "set and forget" RR
[ ] Log daily in trading journal
[ ] Weekend review of all positions
[ ] RR requires active management
[ ] Remember: Passive = dangerous
```

---

## Real-World Examples

### 1. Pension Duration Cut via Futures

**Setup (November 2024):**

- NVDA at $500 (AI boom accelerating)
- Strong uptrend from $420
- Earnings beat last quarter
- Sector momentum strong
- IV Rank: 48%

**Conviction: 9/10 bullish**
- AI adoption accelerating
- NVDA market leader
- Expect move to $550+

**Skew analysis:**

- $475 put: IV = 42%, costs $16.00
- $525 call: IV = 36%, costs $15.00
- **Net credit: $1.00 ($100)**

**Trade: Bullish Risk Reversal**

**Structure:**

- Sell $475 put for $16.00 (5% OTM)
- Buy $525 call for $15.00 (5% OTM)
- Net credit: $1.00 = $100
- DTE: 75 days
- Dead zone: $474-$526 ($52 range)

**Position sizing:**

- $100,000 account
- Risk if assigned: $47,500
- Position: 2 contracts (conservative)
- Total credit: $200

**Management plan:**

- Close if stock > $535 (profit target)
- Exit if stock < $485 (short put threatened)
- Check thesis weekly

**Trade progression:**

**Week 1-3:**

- NVDA consolidates $495-$510
- In dead zone (no profit yet)
- Position value: +$50 (small gain from credit + IV decline)

**Week 4-6:**

- AI news accelerates
- NVDA rallies to $525 (call strike)
- Position value: +$2,400 (call ITM)

**Week 7:**

- NVDA surges to $545
- Call deep ITM
- Position value: $20 × 100 × 2 = $4,000
- **Close at $545!**

**Final results:**

- Entry: $1.00 credit × 2 = $200
- Exit: Sold RR for $4,000
- **Net profit: $4,200**
- **ROI: 2,100% (on credit), 8.8% (on assignment risk)**
- **Time: 48 days**

**Key success factors:**

1. Strong conviction (9/10)
2. Thesis validated (AI boom continued)
3. Collected credit from skew
4. Closed at good profit ($545, not greedy)
5. Conservative sizing (2 contracts)

**Lessons:**

- RR works beautifully when conviction correct
- Zero-cost leverage is powerful
- Credit collection was bonus
- **Direction + skew = winning combo**

### 2. Transition Risk Hedge

**Setup (October 2024):**

- TSLA at $220 (down from $280)
- Resistance at $230
- Fundamentals weakening
- Deliveries disappointing
- IV Rank: 55%

**Conviction: 7/10 bearish**
- Market shifting away from EVs
- Competition increasing
- Elon distracted with Twitter
- **Mistake: 7/10 not strong enough**

**Trade: Bearish Risk Reversal**

**Structure:**

- Sell $235 call for $9.00
- Buy $205 put for $10.00
- Net debit: $1.00 = $100
- DTE: 60 days
- Dead zone: $205-$235 ($30 range)

**What went wrong:**

**Week 1-2:**

- TSLA consolidates $218-$225
- Dead zone (no profit)
- Opportunity cost building

**Week 3:**

- Elon announces new product
- Retail excitement
- TSLA gaps to $238 (above call strike!)
- **Short call now ITM**

**Week 4:**

- TSLA continues rally to $255
- Short call deep ITM
- Position value: -$20 × 100 = -$2,000
- **Should have closed here!**
- **Mistake: Held, hoping for reversal**

**Week 5-6:**

- TSLA rallies to $280 (parabolic)
- Momentum unstoppable
- Position value: -$45 × 100 = -$4,500
- **Finally closed at $275**

**Final results:**

- Entry: -$1.00 debit = -$100
- Exit: Bought back RR for -$4,000
- **Net loss: -$4,100**

**Compounding mistakes:**

1. Conviction only 7/10 (should have been 8+)
2. Fought momentum (parabolic rally)
3. Didn't close when call breached
4. Let loss run from -$2,000 to -$4,100
5. Hoped instead of managed

**Lessons learned:**

1. **Need 8+ conviction for RR**
   - 7/10 too weak
   - RR is aggressive strategy
   - Requires HIGH conviction

2. **Never fight parabolic moves**
   - TSLA had momentum
   - Fighting it was mistake
   - Should have exited immediately

3. **Close when short strike breached**
   - Call went ITM at $238
   - Should have closed at -$2,000
   - Instead held to -$4,100
   - **Stubbornness cost $2,100**

4. **Risk reversals unforgiving when wrong**
   - Unlimited loss on short call
   - Losses accelerated quickly
   - No risk-defined protection
   - **Get out fast when wrong**

**What should have been done:**

- Not entered (conviction too weak)
- Or closed immediately at $238 (call strike breach)
- Or never fought obvious momentum
- **Better to miss trade than force wrong one**

### 3. Portable Alpha with Futures

**Setup (December 2024):**

- SPY corrected from $580 → $550 (-5.2%)
- Market panic, VIX spiked to 25
- Found support at $548
- Economic data still strong
- IV Rank: 68% (elevated)

**Skew analysis:**

- Put skew extreme (panic buying puts)
- $540 put: IV = 38%, costs $8.50
- $570 call: IV = 28%, costs $6.00
- **Net credit: $2.50 ($250!)**

**The opportunity:**

- Extreme skew from panic
- Fundamentals still bullish
- Technical support holding
- **Perfect RR setup**

**Conviction: 8/10 bullish**
- Correction healthy, not crisis
- Support levels strong
- Expect recovery rally
- Get PAID $2.50 for the position!

**Trade: Bullish Risk Reversal**

**Structure:**

- Sell $540 put for $8.50 (2% below support)
- Buy $570 call for $6.00 (above recent high)
- Net credit: $2.50 = $250 per RR
- DTE: 70 days
- Dead zone: $537.50-$572.50

**Position sizing:**

- 4 contracts
- Total credit: $1,000
- Risk if assigned: $216,000 (but unlikely)

**Trade progression:**

**Week 1:**

- SPY bounces to $555
- VIX drops to 20
- IV contracting (helping position)
- Position value: +$500 (credit + IV drop)

**Week 2-3:**

- SPY rallies to $565
- Approaching call strike
- IV drops to 22%
- Position value: +$1,800

**Week 4:**

- SPY breaks to $575 (above call)
- Call ITM by $5
- Position value: $5 × 100 × 4 + $1,000 credit = $3,000
- **Close at 50% of dead zone width achieved**

**Final results:**

- Entry: +$2.50 credit × 4 = +$1,000
- Exit: RR worth $3,000
- **Net profit: $3,000**
- **ROI: 300% (on credit), 1.4% (on assignment risk)**
- **Time: 28 days**

**Why this was perfect:**

1. **Extreme skew entry**
   - Collected $2.50 credit (huge!)
   - Skew premium at peak
   - Got paid to take bullish stance

2. **Post-correction timing**
   - Bought panic bottom
   - Support holding
   - Recovery rally likely

3. **Triple profit drivers:**

   - Directional move (SPY rallied)
   - IV contraction (VIX 25 → 22)
   - Skew normalization (puts cheapened)

4. **Disciplined exit**
   - Closed at good profit
   - Didn't get greedy
   - Took $3,000, moved on

**This is the IDEAL risk reversal trade:**

- High conviction + extreme skew + post-panic entry

### 4. Tactical Duration Extension

**Scenario: Running 4 RRs Simultaneously**

**Portfolio: $150,000 account**

**Positions:**

**Bullish RRs:**

1. **NVDA** (60 DTE): Short $475 put, Long $525 call
   - Credit: $2.00
   - Status: +15% (NVDA at $510)
   
2. **MSFT** (75 DTE): Short $395 put, Long $425 call
   - Credit: $1.50
   - Status: +5% (MSFT at $408)

**Bearish RRs:**

3. **TSLA** (55 DTE): Short $230 call, Long $200 put
   - Debit: -$0.50
   - Status: +25% (TSLA at $210)
   
4. **Overvalued Biotech** (65 DTE): Short $85 call, Long $65 put
   - Credit: $0.50
   - Status: -10% (stock at $82)

**Portfolio Analysis:**

**Net credit collected:** +$3.50 = $350
**Current P/L:** +$1,200
**Portfolio delta:** +20 (slightly bullish, balanced)
**Margin used:** $35,000 (23% of account)

**Management decisions:**

**Week 2 review:**

**TSLA (25% profit):**

- Target reached early
- Close, take profit
- Free up capital

**Biotech (-10%):**

- Thesis still intact
- Stock bounced but still bearish
- Hold, monitor closely

**NVDA & MSFT:**

- Both working
- Hold for more profit

**Week 4 adjustments:**

**NVDA (+40%):**

- Stock at $520 (call strike nearby)
- Close at 40% profit
- Don't risk reversal

**Biotech (-15%):**

- Stock rallied to $85 (call strike)
- Thesis breaking (positive trial data)
- **Close immediately**
- Accept -15% loss before worse

**New positions:**

- Open new bullish RR on GOOGL (different sector)
- Replace closed positions
- Maintain diversification

**Month-end results:**

**Closed:**

- TSLA: +$625 (25% → closed)
- NVDA: +$800 (40% → closed)
- Biotech: -$375 (15% loss → closed)

**Open:**

- MSFT: +$250 (holding)
- GOOGL: +$50 (new position)

**Net: +$1,350 in one month**
**ROI: 3.9% monthly (46% annualized) on deployed capital**

**Lessons from portfolio approach:**

1. **Diversification worked**
   - Mix of bullish/bearish
   - Different sectors
   - One loser didn't kill portfolio

2. **Profit-taking discipline**
   - Closed winners at good levels
   - Didn't get greedy
   - Freed capital for new opportunities

3. **Loss cutting when thesis breaks**
   - Biotech thesis invalidated
   - Exited at -15% not -50%
   - Preserved capital

4. **Continuous rolling**
   - Always have 3-4 positions
   - Replace as closed
   - Steady income stream

5. **Balanced approach**
   - Net delta near neutral
   - Not all-in one direction
   - Portfolio resilience

---


---



## Final Wisdom

> "Risk reversals are deceptively simple - sell one option, buy another, pay nothing. But this simplicity hides profound risk: unlimited loss on one side, dead zone opportunity cost, and assignment dangers. Use them ONLY when you have very strong directional conviction - 8 out of 10 or higher. The zero cost is not free; you're accepting insurance obligations in exchange for leverage. The best RR trades exploit extreme volatility skew during panic, entering when puts are absurdly expensive and calls are cheap. You get paid to take a bullish stance you wanted anyway. Master the conviction checklist, respect the dead zone, and never let assignment happen. Remember: RRs are synthetic stock without the capital - powerful when right, devastating when wrong."

**Key to success:**

- High conviction only (8+/10)
- Exploit volatility skew for credit
- Enter post-panic (IV extremes)
- Monitor assignment risk constantly
- Close ITM options week before expiration
- Accept dead zone cost
- Stop out when thesis breaks
- Never overleverage

**Most important:** Risk reversals require STRONG directional conviction - if you're not very confident, use a different strategy! 🎯📈📉